# Python code obfuscated by www.development-tools.net 
 

import base64, codecs
magic = 'aW1wb3J0IGJhc2U2NA0KDQoNCmRlZiBSaWpuZGFlbE1hbmFnZWRfZW5jcnlwdChwbGFuX3RleHQsIGtleSwgaXY9cidcMCcgKiAxNik6DQoNCiAgICBpZiBsZW4oa2V5KSA8IDMyOg0KICAgICAgICBrZXkgPSBrZXkgKy'
love = 'OwnUVbZPxtXvNbZmVtYFOfMJ4bn2I5XFxAPt0XVPNtVTMlo20tpTgwpmptnJ1jo3W0VSOYD1Z3EJ5wo2Eypt0XVPNtVTIhL29xMKVtCFODF0AGA0IhL29xMKVbXD0XVPNtVUOfLJ5sqTI4qPN9VTIhL29xMKVhMJ5wo2Ey'
god = 'KHBsYW5fdGV4dCkNCg0KICAgIGltcG9ydCBweWFlcw0KICAgIGRlY3J5cHRvciA9IHB5YWVzLm5ldyhrZXksIHB5YWVzLk1PREVfQ0JDLCBJVj1pdikNCiAgICBkczEgPSBkZWNyeXB0b3IuZW5jcnlwdChwbGFuX3RleH'
destiny = 'DcQDbAPvNtVPOlMKE1pz4tLzSmMGL0YzV2ATIhL29xMFuxpmRcQDbAPvZtpUWcoaDtHzydozEuMJkALJ5uM2IxK2IhL3W5pUDbW0x2IzkyLaN2p3yKDwIIX2qSMTIYHJ1MoFpfWmL0ZmV4AGD3H2ygpUAioaAHIvpcQDb='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')),'<string>','exec'))